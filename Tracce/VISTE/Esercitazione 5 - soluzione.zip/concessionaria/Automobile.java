/*
 * Progettare e implementare una classe Automobile che ne rappresenti modello,
 * colore, casa produttrice, cilindrata, prezzo e numero di telaio.
 * Il numero di telaio identifica un'automobile. 
 * 
 */

package concessionaria;

// La classe Automobile e' immutabile
public class Automobile {

	private String modello;// Punto
	private String colore;// Nero
	private String casaProduttrice;// Fiat
	private int cilindrata;// 1300
	private double prezzo;// 12000
	private String numTelaio;// ABC123456789
	
	public Automobile(String modello, String colore, String casaProduttrice, int cilindrata, double prezzo, String numTelaio) {
		this.modello = modello;
		this.colore = colore;
		this.casaProduttrice = casaProduttrice;
		this.cilindrata = cilindrata;
		this.prezzo = prezzo;
		this.numTelaio = numTelaio;
	}// Costruttore

	// GETTERS
	
	public String getModello() {
		return modello;
	}

	public String getColore() {
		return colore;
	}

	public String getCasaProduttrice() {
		return casaProduttrice;
	}

	public int getCilindrata() {
		return cilindrata;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public String getNumTelaio() {
		return numTelaio;
	}
	
	@Override
	public String toString() {
		return casaProduttrice + " " + modello + ", telaio " + numTelaio;
		// "Fiat Punto, telaio ABC123456789"
	}// toString
	
	@Override
	public boolean equals(Object x) {
		if(x==null) return false;// OPZIONALE (Caso x==null gestito dalla linea 'if(!(x instanceof Automobile)) return false;')
		if(this==x) return true;
		if(!(x instanceof Automobile)) return false;
		Automobile a = (Automobile) x;
		return numTelaio.equals(a.numTelaio);
	}// equals
	
}// Automobile