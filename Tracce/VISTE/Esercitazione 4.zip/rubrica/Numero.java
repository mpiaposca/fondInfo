package rubrica;

// La classe Numero e' immutabile
public class Numero {

	private String tipo;// casa, lavoro, ...
	private String numero;// +39 340 123 456

	public Numero(String tipo, String numero) {
		this.tipo = tipo;
		this.numero = numero;
	}// costruttore

	/*
	 * Il construttore per copia si pu� evitare, essendo Numero una classe immutabile
	public Numero(Numero n) {
		tipo = n.tipo;
		numero = n.numero;
	}// costruttore per copia
	*/

	// Versione alternativa del costruttore per copia
	public Numero(Numero n) {
		this(n.tipo, n.numero);
	}

	public String getTipo() {
		return this.tipo;
	}

	public String getNumero() {
		return numero;
	}

	public String toString() {
		return tipo + ": " + numero;
	}// toString

	public boolean equals(Object o) {
		if(o==null)
			return false;
		if(this==o)
			return true;

		if(!(o instanceof Numero))
			return false;
		Numero n = (Numero) o;
		return tipo.equals(n.tipo) && numero.equals(n.numero);
	}// equals

	public static void main(String[] args) {
		Numero n1 = new Numero("casa", "+39340123456");
		Numero n2 = new Numero("lavoro", "+39389654321");
		System.out.println( n1.getNumero() );
		System.out.println( n2.getTipo() );
		Numero n3 = new Numero(n1);
		System.out.println( n3.getTipo() + ", " + n3.getNumero());
		String s = n1.toString();
		System.out.println(s);
		System.out.println( n2 );// System.out.println( n2.toString() );
		Numero n4 = n1;// aliasing tra n4 e n1
		boolean b = n1.equals(n4);
		System.out.println(b);
		String s1 = "scuola";
		b = n1.equals(s1);
		System.out.println(b);
		Numero n5 = null;
		b = n1.equals(n5);
		System.out.println(b);
	}// main

}// Numero
