package rubrica;

// La classe Contatto e' mutabile
public class Contatto {

	private String nome, cognome, email;
	private Numero[] numeri;
	private int numeriMemorizzati;

	public Contatto(String nome, String cognome) {
		this.nome = nome;
		this.cognome = cognome;
		email = null;
		numeri = new Numero[5];
		numeriMemorizzati = 0;
	}// costruttore

	// c.numeri = {n1, n2, n3, null, null}, c.numeriMemorizzati = 3
	// numeri   = {n1, n2, n3, null, null}

	public Contatto(Contatto c) {
		nome = c.nome;
		cognome = c.cognome;
		email = c.email;
		numeriMemorizzati = c.numeriMemorizzati;
		numeri = new Numero[c.numeri.length];

		for(int i=0; i<c.numeriMemorizzati; i++)
			numeri[i] = c.numeri[i];
	}// costruttore per copia

	// GETTERS

	public String getNome() { return nome; }

	public String getCognome() { return cognome; }

	public String getEmail() { return email==null? "" : email; }

	// SETTERS

	public void setNome(String nome) { this.nome = nome; }

	public void setCognome(String cognome) { this.cognome = cognome; }

	public void setEmail(String email) { this.email = email; }


	public Numero estraiNumero(String tipo) {
		Numero ris = null;
		for(int i=0; i<numeriMemorizzati; i++) {// numeriMemorizzati <= numeri.length
			if(numeri[i].getTipo().equals(tipo)) {
				ris = numeri[i];
				break;
			}
		}// for
		return ris;
	}// estraiNumero

	//           0   1   2    3     4
	// numeri = {n1, n2, n3, null, null}, numeriMemorizzati = 3

	//           0   1   2   3   4
	// numeri = {n1, n2, n3, n4, n5}, numeriMemorizzati = 5


	// CASO array numeri "saturo" (numeriMemorizzati==numeri.length)
	// 1. nuovo = {null, null, null, null, null, null, null, null, null, null}
	// 2. nuovo = {n1, n2, n3, n4, n5, null, null, null, null, null}, numeriMemorizzati = 5
	// 3. nuovo = {n1, n2, n3, n4, n5, n, null, null, null, null}
	// 4. numeri = {n1, n2, n3, n4, n5, n, null, null, null, null}, numeriMemorizzati = 5
	// 5. (istruzione fuori dal blocco else) numeriMemorizzati = 6
	public void aggiungiNumero(Numero n) {
		if(numeriMemorizzati < numeri.length) {
			numeri[numeriMemorizzati] = n;
		} else {// array numeri "saturo" (numeriMemorizzati==numeri.length)
			Numero[] nuovo = new Numero[numeriMemorizzati * 2];
			for(int i=0; i<numeriMemorizzati; i++)
				nuovo[i] = numeri[i];
			nuovo[numeriMemorizzati] = n;
			numeri = nuovo;
		}
		numeriMemorizzati++;
	}// aggiungiNumeri

	//           0   1   2   3   4
	// numeri = {n1, n2, n3, n4, null}, numeriMemorizzati = 4, indice=1
	// 1. nuovo = {null, null, null, null, null}
	// 2. nuovo = {n1, n3, n4, null, null}
	// 3. numeriMemorizzati = 3
	// 4. numeri = {n1, n3, n4, null, null}
	private void eliminaNumero(int indice) {
		Numero[] nuovo = new Numero[numeri.length];
		for(int i=0; i<indice; i++)
			nuovo[i] = numeri[i];
		for(int i=indice+1; i<numeriMemorizzati; i++)
			nuovo[i-1] = numeri[i];
		numeriMemorizzati--;
		numeri = nuovo;

	}// indice


	//    		    0   1   2   3   4
	//    numeri = {n1, n2, n3, n4, null}, numeriMemorizzati = 4, indice=1
	// 1. numeri = {n1, n3, n4, n4, null}
	// 2. numeri = {n1, n3, n4, null, null}
	// 3. numeriMemorizzati = 3
	@SuppressWarnings("unused")
	private void eliminaNumero2(int indice) {
		for(int i=indice+1; i<numeriMemorizzati; i++)
			numeri[i-1] = numeri[i];
		numeri[numeriMemorizzati-1] = null;// OPZIONALE
		numeriMemorizzati--;
	}// versione alternatica di eliminaNumeri(int indice)

	public void eliminaNumero(Numero n) {
		int indice = -1;
		for(int i=0; i<numeriMemorizzati; i++)
			if(numeri[i].equals(n)) {
				indice = i;
				break;
			}
		if(indice!=-1)
			eliminaNumero(indice);
	}// eliminaNumero

	public void eliminaNumero(String tipo) {
		int indice = -1;
		for(int i=0; i<numeriMemorizzati; i++)
			if(numeri[i].getTipo().equals(tipo)) {
				indice = i;
				break;
			}
		if(indice!=-1)
			eliminaNumero(indice);
	}// eliminaNumero

	public String toString() {
		String ret = "=================================\n";
		ret += nome + " " + cognome + "\n";
		if(email!=null)
			ret += "Email: " + email + "\n";
		for(int i=0; i<numeriMemorizzati; i++)
			ret += numeri[i] + "\n";// ret += numeri[i].toString() + "\n";
		ret += "=================================\n";
		return ret;
	}// toString

	public boolean equals(Object o) {
		if(o==null) return false;
		if(this==o) return true;
		if(!(o instanceof Contatto)) return false;

		Contatto c = (Contatto) o;
		if(!nome.equals(c.nome) || !cognome.equals(c.cognome) || !getEmail().equals(c.getEmail()) || numeriMemorizzati!=c.numeriMemorizzati)
			return false;

		// Rimane da confrontare il contenuto di this.numeri con c.numeri
		for(int i=0; i<numeriMemorizzati; i++)
			if(!numeri[i].equals(c.numeri[i]))
				return false;

		return true;
	}// equals


}// Contatto
































