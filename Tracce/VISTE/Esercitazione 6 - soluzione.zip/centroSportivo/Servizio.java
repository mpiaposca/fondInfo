package centroSportivo;


/*
 * La classe Servizio � caratterizzata dai seguenti attributi: codice (identificativo), numero di posti
 * liberi (costantemente aggiornato), turno (sono possibili turni 'senior', 'advanced' e 'junior')
 * e costo settimanale (intero).
 */

public class Servizio implements Comparable<Servizio> {// Genera oggetti mutabili

	private int codice;
	private int nrPosti; // numero di posti disponibili totali
	private int turno; //senior=0, advanced=1, junior=2

	private int costoSettimanale;
	private int postiOccupati; // <= nrPosti

	// Posti Liberi = nrPosti - postiOccupati

	public Servizio(int codice, int turno, int costoSettimanale, int nrPosti) {
		this.codice = codice;
		this.turno = turno; //senior=0, advanced=1, junior=2
		this.costoSettimanale = costoSettimanale;
		this.nrPosti = nrPosti;
		postiOccupati = 0;
	}// Costruttore

	// GETTERS

	public int getCodice() { return codice; }

	public int getTurno() { return turno; }

	public int getCostoSettimanale() { return costoSettimanale; }

	public int getNrPosti() { return nrPosti; }

	public int getPostiOccupati() { return postiOccupati; }

	public void incrementaPostiOccupati() { postiOccupati++; }

	public int getPostiLiberi() {
		return nrPosti - postiOccupati;
	}// getPostiLiberi

	public String toString() {
		String turnoStr;
		if(turno==0)
			turnoStr = "senior";
		else if(turno==1)
			turnoStr = "advanced";
		else// turno==2
			turnoStr = "junior";

		return "Servizio con codice=" + codice + ", turno=" + turnoStr + ", costo settimanale=" + costoSettimanale +
				", num. posti totali=" + nrPosti + ", posti occupati=" + postiOccupati;
	}// toString

	public boolean equals(Object o) {
		if(o==null) return false;
		if(this==o) return true;
		if(!(o instanceof Servizio)) return false;
		Servizio s = (Servizio) o;
		return codice == s.codice;
	}// equals

	public int compareTo(Servizio s) {
		if(this.turno < s.turno)
			return -1;
		if(this.turno > s.turno)
			return 1;
		if(this.costoSettimanale > s.costoSettimanale)
			return -1;
		if(this.costoSettimanale < s.costoSettimanale)
			return 1;
		return 0;
	}// compareTo

}// Servizio







