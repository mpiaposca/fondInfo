package centroSportivo;

import java.util.ArrayList;

/*
 * La classe Tesserato � caratterizzata dai seguenti attributi: nome, cognome, data di nascita, codice fiscale
 * (identificativo), codice della tessera, data di scadenza e lista degli abbonamenti.

 * Per semplicit�, tutte le date sono rappresentate come numeri interi (giorni trascorsi dall'1/1/2000).
 * 
 */

public class Tesserato {// Genera oggetti mutabili

	private String nome, cognome;
	private int dataNascita;
	private String cf;
	private int codiceTessera;
	private int dataScadenza;
	private ArrayList<Abbonamento> listaAbbonamenti;
	
	public Tesserato(String nome, String cognome, int dataNascita, String cf, int codiceTessera, int dataScadenza) {
		this.nome = nome;
		this.cognome = cognome;
		this.dataNascita = dataNascita;
		this.cf = cf;
		this.codiceTessera = codiceTessera;
		this.dataScadenza = dataScadenza;
		listaAbbonamenti = new ArrayList<>();
	}// Costruttore
	
	// GETTERS
	
	public String getNome() { return nome; }
	
	public String getCognome() { return cognome; }
	
	public int getDataNascita() { return dataNascita; }
	
	public String getCf() { return cf; }
	
	public int getCodiceTessera() { return codiceTessera; }
	
	public int getDataScadenza() { return dataScadenza; }
	
	public ArrayList<Abbonamento> getListaAbbonamenti(){
		return new ArrayList<>(listaAbbonamenti);
	}
	
	public void aggiungiAbbonamento(Abbonamento a) {
		listaAbbonamenti.add(a);
	}// aggiungiAbbonamento
	
	public String toString() {
		return "Tesserato con codice tessera=" + codiceTessera + ", data di scadenza=" + dataScadenza + ", nome=" + nome + 
				", cognome=" + cognome + ", data di nascita=" + dataNascita + ", CF=" + cf + ", abbonamenti=" + listaAbbonamenti;
	}// toString
	
	public boolean equals(Object o) {
		if(o==null) return false;// OPZIONALE
		if(this==o) return true;
		if(!(o instanceof Tesserato)) return false;
		
		Tesserato t = (Tesserato) o;
		return cf.equals(t.cf);
	}// equals
	
}// Tesserato














