package pubblicazioni;

import java.util.*;

public class Sistema 
{	private static ArrayList<Autore> autori = new ArrayList<>();
	private static ArrayList<Pubblicazione> pubblicazioni = new ArrayList<>();

	public static void aggiungiAutore(Autore a)
	{	autori.add(a);		
	}
	
	public static void aggiungiPubblicazione(Pubblicazione p)
	{	pubblicazioni.add(p);
	}
	
	public static ArrayList<String> pubblicazioniCitta(String s)
	{	ArrayList<String> ret = new ArrayList<>();
		for(Pubblicazione p : pubblicazioni)
			if(scrittaSoloDaResidenti(p,s))
				ret.add(p.getCodice());
		return ret;		 
	}
	
	private static boolean scrittaSoloDaResidenti(Pubblicazione p, String s) 
	{	ArrayList<String> nomiAutoriP = p.getNomiAutori();
		for(String nomeAutore : nomiAutoriP)
			if(!trovaAutore(nomeAutore).getCittaResidenza().equals(s))
				return false;
		return true;
	}
	
	private static Autore trovaAutore(String nome)
	{	for(Autore a : autori)
			if(a.getNome().equals(nome))
				return a;
		return null;		
	}
	
	public static ArrayList<Autore> individuali(int d1, int d2)
	{	ArrayList<Autore> ret = new ArrayList<>();
		for(Pubblicazione p : pubblicazioni)
			if(p.eIndividuale() && p.getData() >= d1 && p.getData() <= d2)
			{	Autore a = trovaAutore(p.getNomiAutori().get(0)); 
				if(!ret.contains(a))
					ret.add(a);
			}
		return ret;		
	}
	
	public static ArrayList<Pubblicazione> coautori(Autore a, Autore b)
	{	ArrayList<Pubblicazione> ret = new ArrayList<>();
		for(Pubblicazione p : pubblicazioni)
		{	ArrayList<String> nomiAutoriP = p.getNomiAutori();
			if(nomiAutoriP.contains(a.getNome()) && nomiAutoriP.contains(b.getNome()))
				ret.add(p);			
		}
		Collections.sort(ret);
		return ret;		
	}
}



