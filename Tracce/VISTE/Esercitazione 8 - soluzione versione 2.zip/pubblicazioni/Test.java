package pubblicazioni;

import java.util.*;
import IO.*;

public class Test 
{	public static void main(String[] args)
	{	Autore a1 = new Autore("Rossi", "Roma");
		Autore a2 = new Autore("Bianchi", "Torino");
		Autore a3 = new Autore("Verdi", "Cosenza");
		Autore a4 = new Autore("Neri", "Cosenza");
		Autore a5 = new Autore("Marroni", "Milano");
		Autore a6 = new Autore("Gialli", "Milano");
		Sistema.aggiungiAutore(a1);
		Sistema.aggiungiAutore(a2);
		Sistema.aggiungiAutore(a3);
		Sistema.aggiungiAutore(a4);
		Sistema.aggiungiAutore(a5);
		Sistema.aggiungiAutore(a6);
		
		ArrayList<String> nomiAutori = new ArrayList<>();
		nomiAutori.add("Rossi");
		nomiAutori.add("Bianchi");
		nomiAutori.add("Neri");
		Pubblicazione p1 = new Pubblicazione("pub1", "Titolo di p1", nomiAutori, 1);
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Bianchi");
		nomiAutori.add("Neri");
		Pubblicazione p2 = new Pubblicazione("pub2", "Titolo di p2", nomiAutori, 2); 
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Gialli");
		nomiAutori.add("Marroni");
		Pubblicazione p3 = new Pubblicazione("pub3", "Titolo di p3", nomiAutori, 2);
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Gialli");
		Pubblicazione p4 = new Pubblicazione("pub4", "Titolo di p4", nomiAutori, 2);
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Neri");
		nomiAutori.add("Verdi");
		Pubblicazione p5 = new Pubblicazione("pub5", "Titolo di p5", nomiAutori, 1); 
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Bianchi");
		Pubblicazione p6 = new Pubblicazione("pub6", "Titolo di p6", nomiAutori, 1);
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Gialli");
		nomiAutori.add("Rossi");
		nomiAutori.add("Bianchi");
		nomiAutori.add("Neri");
		Pubblicazione p7 = new Pubblicazione("pub7", "Titolo di p7", nomiAutori, 2);
		nomiAutori = new ArrayList<>();
		nomiAutori.add("Verdi");
		Pubblicazione p8 = new Pubblicazione("pub8", "Titolo di p8", nomiAutori, 3);
		Sistema.aggiungiPubblicazione(p1);
		Sistema.aggiungiPubblicazione(p2);
		Sistema.aggiungiPubblicazione(p3);
		Sistema.aggiungiPubblicazione(p4);
		Sistema.aggiungiPubblicazione(p5);
		Sistema.aggiungiPubblicazione(p6);
		Sistema.aggiungiPubblicazione(p7);
		Sistema.aggiungiPubblicazione(p8);
			
		IO.println(Sistema.pubblicazioniCitta("Milano"));
		IO.println(Sistema.individuali(2, 3));
		IO.println(Sistema.coautori(a2, a4));
	}
}
