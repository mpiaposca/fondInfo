package pubblicazioni;

public class Autore 
{	private String nome;
	private String cittaResidenza;
	
	public Autore(String nome, String cittaResidenza) 
	{	this.nome = nome;
		this.cittaResidenza = cittaResidenza;
	}

	public String getNome() 
	{	return nome;
	}

	public String getCittaResidenza() 
	{	return cittaResidenza;
	}
	
	public boolean equals(Object o)
	{	if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof Autore))
			return false;
		Autore a = (Autore)o;
		return nome.equals(a.nome);
	}
	
	public String toString()
	{	return "Autore "+nome+" di "+cittaResidenza;		
	}
}
