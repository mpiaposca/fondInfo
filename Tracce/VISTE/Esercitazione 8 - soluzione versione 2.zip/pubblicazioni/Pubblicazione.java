package pubblicazioni;

import java.util.*;

public class Pubblicazione implements Comparable<Pubblicazione>
{	private String codice;
	private String titolo;
	private ArrayList<String> nomiAutori;
	private int data;
	
	public Pubblicazione(String codice, String titolo, ArrayList<String> nomiAutori, int data) 
	{	this.codice = codice;
		this.titolo = titolo;
		this.nomiAutori = new ArrayList<>(nomiAutori);
		this.data = data;
	}

	public String getCodice() 
	{	return codice;
	}

	public String getTitolo() 
	{	return titolo;
	}

	public ArrayList<String> getNomiAutori() 
	{	return new ArrayList<>(nomiAutori);
	}

	public int getData() 
	{	return data;
	}
	
	public boolean equals(Object o)
	{	if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof Pubblicazione))
			return false;
		Pubblicazione p = (Pubblicazione)o;
		return codice.equals(p.codice);
	}
	
	public String toString()
	{	return "Pubbl. codice "+codice+" '"+titolo+"' "+nomiAutori+" data: "+data;		
	}
	
	public boolean eIndividuale()
	{	return nomiAutori.size() == 1;		
	}
	
	public int compareTo(Pubblicazione p)
	{	if(data < p.data)
			return -1;
		if(data == p.data)
			return 0;
		return 1;		
	}
}
