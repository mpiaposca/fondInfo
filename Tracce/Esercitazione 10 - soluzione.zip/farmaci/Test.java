package farmaci;

import java.util.*;
import IO.*;

public class Test 
{	public static void main(String[] args)
	{	Produttore p1 = new Produttore(1, "produttore 1", "Italia");
		Produttore p2 = new Produttore(2, "produttore 2", "Francia");
		Produttore p3 = new Produttore(3, "produttore 3", "Inghilterra");
		Produttore p4 = new Produttore(4, "produttore 4", "Italia");
		ArrayList<Produttore> produttori = new ArrayList<>();
		produttori.add(p1);
		produttori.add(p2);
		produttori.add(p3);
		produttori.add(p4);
		
		ArrayList<String> principiAttivi = new ArrayList<>();
		principiAttivi.add("principioA");
		principiAttivi.add("principioB");
		principiAttivi.add("principioC");
		principiAttivi.add("principioD");
		principiAttivi.add("principioE");
		principiAttivi.add("principioF");
		
		ArrayList<String> pa = new ArrayList<>();
		pa.add("principioA");
		pa.add("principioB");
		pa.add("principioC");
		Farmaco f1 = new Farmaco(1, "farmaco 1", 1, 1.5, pa);
		pa = new ArrayList<>();
		pa.add("principioC");
		pa.add("principioD");
		Farmaco f2 = new Farmaco(2, "farmaco 2", 1, 1, pa);
		pa = new ArrayList<>();
		pa.add("principioC");
		pa.add("principioD");
		Farmaco f3 = new Farmaco(3, "farmaco 3", 2, 2, pa);
		pa = new ArrayList<>();
		pa.add("principioC");
		pa.add("principioE");
		Farmaco f4 = new Farmaco(4, "farmaco 4", 3, 3, pa);
		pa = new ArrayList<>();
		pa.add("principioA");
		pa.add("principioF");
		Farmaco f5 = new Farmaco(5, "farmaco 5", 3, 2.5, pa);
		pa = new ArrayList<>();
		pa.add("principioA");
		pa.add("principioF");
		Farmaco f6 = new Farmaco(6, "farmaco 6", 4, 0.5, pa);
		ArrayList<Farmaco> farmaci = new ArrayList<>();
		farmaci.add(f1);
		farmaci.add(f2);
		farmaci.add(f3);
		farmaci.add(f4);
		farmaci.add(f5);
		farmaci.add(f6);
		
		Gestione g = new Gestione(produttori,farmaci,principiAttivi);

		IO.println(g.farmacoCaro("principioC"));
		IO.println(g.esclusivisti());
		IO.println(g.universali());
	}

}
