package farmaci;

import twitter.Tweet;
import twitter.Utente;

public class Produttore 
{	private int codice;
	private String nome;
	private String nazione;
	
	public Produttore(int codice, String nome, String nazione) 
	{	this.codice = codice;
		this.nome = nome;
		this.nazione = nazione;
	}

	public int getCodice() 
	{	return codice;
	}

	public String getNome() 
	{	return nome;
	}

	public String getNazione() 
	{	return nazione;
	}
	
	public String toString()
	{	return "Produttore "+nome+", codice "+codice+", nazione "+nazione; 
	}
	
	public boolean equals(Object o)
	{	if(o == this)
			return true;
		if(o == null)
			return false;
		if(!(o instanceof Produttore))
			return false;
		Produttore p = (Produttore)o;
		return codice == p.codice;		
	}
}
