package farmaci;

import java.util.*;

public class Gestione 
{	private ArrayList<Produttore> produttori;
	private ArrayList<Farmaco> farmaci;
	private ArrayList<String> principiAttivi;
	
	public Gestione(ArrayList<Produttore> produttori, ArrayList<Farmaco> farmaci, ArrayList<String> principiAttivi) 
	{	this.produttori = new ArrayList<>(produttori);
		this.farmaci = new ArrayList<>(farmaci);
		this.principiAttivi = new ArrayList<>(principiAttivi);
	}
	
	public String farmacoCaro(String p)
	{	String nomeFarmacoMax = null;
		double prezzoMax = 0;
		for(Farmaco f : farmaci)
			if(f.contienePrincipioAttivo(p) && f.getPrezzo() > prezzoMax)
			{	nomeFarmacoMax = f.getNome();
				prezzoMax = f.getPrezzo();				
			}
		return nomeFarmacoMax;		
	}
	
	public ArrayList<Produttore> esclusivisti()
	{	ArrayList<Farmaco> farmaciInteresse = farmaciSenzaEquivalentiAltriProduttori();
		ArrayList<Produttore> ret = new ArrayList<>();
		for(Farmaco f : farmaciInteresse)
		{	int codiceProduttore = f.getCodiceProduttore();
			Produttore p = cercaProduttore(codiceProduttore);
			if(!ret.contains(p))
				ret.add(p);			
		}
		return ret;
	}
	
	public Produttore cercaProduttore(int codice)
	{	for(Produttore p : produttori)
			if(p.getCodice() == codice)
				return p;
		return null;		
	}
	
	private ArrayList<Farmaco> farmaciSenzaEquivalentiAltriProduttori()
	{	ArrayList<Farmaco> ret = new ArrayList<>();
		for(int i = 0; i < farmaci.size(); i++)
		{	Farmaco fi = farmaci.get(i);
			boolean senzaEquivalenti = true;
			for(int j = 0; j < farmaci.size() && senzaEquivalenti; j++)
			{	Farmaco fj = farmaci.get(j);
				if(fi.eEquivalente(fj) && fi.getCodiceProduttore() != fj.getCodiceProduttore())
					senzaEquivalenti = false;
			}
			if(senzaEquivalenti)
				ret.add(fi);		
		}
		return ret;		
	}
	
	public ArrayList<String> universali()
	{	ArrayList<String> ret = new ArrayList<>();
		for(String p : principiAttivi)
			if(principioUsatoTutteNazioni(p))
				ret.add(p);
		return ret;		
	}
	
	private boolean principioUsatoTutteNazioni(String p)
	{	ArrayList<String> tutteNazioni = tutteNazioni();
		for(String nazione : tutteNazioni)
			if(!principioUsatoNazione(p,nazione))
				return false;
		return true;		
	}
	
	private ArrayList<String> tutteNazioni()
	{	ArrayList<String> ret = new ArrayList<>();
		for(Produttore p : produttori)
			if(!ret.contains(p.getNazione()))
				ret.add(p.getNazione());
		return ret;		
	}
	
	private boolean principioUsatoNazione(String p, String nazione)
	{	for(Farmaco f : farmaci)
		{	Produttore pf = cercaProduttore(f.getCodiceProduttore());
			if(f.contienePrincipioAttivo(p) && pf.getNazione().equals(nazione))
				return true;	
		}
		return false;		
	}	
}
