package farmaci;

import java.util.*;

public class Farmaco 
{	private int codice;
	private String nome;
	private int codiceProduttore;
	private double prezzo;
	private ArrayList<String> principiAttivi;
	
	public Farmaco(int codice, String nome, int codiceProduttore, double prezzo, ArrayList<String> principiAttivi) 
	{	this.codice = codice;
		this.nome = nome;
		this.codiceProduttore = codiceProduttore;
		this.prezzo = prezzo;
		this.principiAttivi = new ArrayList<String>(principiAttivi);
	}

	public int getCodice() 
	{	return codice;
	}

	public String getNome() 
	{	return nome;
	}

	public int getCodiceProduttore() 
	{	return codiceProduttore;
	}

	public double getPrezzo() 
	{	return prezzo;
	}

	public ArrayList<String> getPrincipiAttivi() 
	{	return new ArrayList<String>(principiAttivi);
	}
	
	public String toString()
	{	return "Farmaco con codice "+codice+", nome "+nome+" produttore cod. "+codiceProduttore+", prezzo "+prezzo+
			" principi attivi: "+principiAttivi;
	}
	
	public boolean equals(Object o)
	{	if(o == this)
			return true;
		if(o == null)
			return false;
		if(!(o instanceof Farmaco))
			return false;
		Farmaco f = (Farmaco)o;
		return codice == f.codice;		
	}
	
	public boolean contienePrincipioAttivo(String p)
	{	return principiAttivi.contains(p);		
	}
	
	public boolean eEquivalente(Farmaco f)
	{	if(principiAttivi.size() != f.principiAttivi.size())
			return false;
		for(String p : principiAttivi)
			if(!f.getPrincipiAttivi().contains(p))
				return false;
		for(String p : f.getPrincipiAttivi())
			if(!principiAttivi.contains(p))
				return false;
		return true;		
	}
}
