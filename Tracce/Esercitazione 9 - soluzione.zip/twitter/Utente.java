package twitter;

public class Utente 
{	private String CF;
	private String citta;
	
	public Utente(String CF, String citta) 
	{	this.CF = CF;
		this.citta = citta;
	}

	public String getCF() 
	{	return CF;
	}

	public String getCitta() 
	{	return citta;
	}
	
	public String toString()
	{	return "Utente con CF "+CF+" di "+citta;
	}
	
	public boolean equals(Object o)
	{	if(o == this)
			return true;
		if(o == null)
			return false;
		if(!(o instanceof Utente))
			return false;
		Utente u = (Utente)o;
		return CF.equals(u.CF);		
	}
}
