package twitter;

import java.util.*;
import IO.*;

public class Test 
{	public static void main(String[] args)
	{	ArrayList<Utente> utenti = new ArrayList<>();
		utenti.add(new Utente("CF1", "Rende"));
		utenti.add(new Utente("CF2", "Cosenza"));
		utenti.add(new Utente("CF3", "Rende"));
		
		ArrayList<Tweet> tweet = new ArrayList<>();
		ArrayList<String> tag = new ArrayList<>();
		tag.add("#capodanno");
		tag.add("#2020");				
		tweet.add(new Tweet("Tw1", "CF1", 1, "Rende", tag));
		tag = new ArrayList<>();
		tag.add("#capodanno");
		tag.add("#concerto");				
		tweet.add(new Tweet("Tw2", "CF1", 1, "Cosenza", tag));
		tag = new ArrayList<>();
		tag.add("#governo");
		tweet.add(new Tweet("Tw3", "CF2", 2, "Rende", tag));
		tag = new ArrayList<>();
		tag.add("#capodanno");
		tweet.add(new Tweet("Tw4", "CF3", 1, "Rende", tag));
		tag = new ArrayList<>();
		tag.add("#governo");
		tweet.add(new Tweet("Tw5", "CF3", 1, "Rende", tag));

		Sistema s = new Sistema(utenti,tweet);
		IO.println(s.cittaDiversa());
		IO.println(s.listaUtenti());
		IO.println(s.tagOfTheDay(1));
	}
}
