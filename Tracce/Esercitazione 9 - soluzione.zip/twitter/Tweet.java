package twitter;

import java.util.*;

public class Tweet 
{	private String codice;
	private String CFutente;
	private int dataEmissione;
	private String cittaEmissione;
	private ArrayList<String> tag;
	
	public Tweet(String codice, String CFutente, int dataEmissione, String cittaEmissione, ArrayList<String> tag) 
	{	this.codice = codice;
		this.CFutente = CFutente;
		this.dataEmissione = dataEmissione;
		this.cittaEmissione = cittaEmissione;
		this.tag = new ArrayList<String>(tag);
	}

	public String getCodice() 
	{	return codice;
	}

	public String getCFutente() 
	{	return CFutente;
	}

	public int getDataEmissione() 
	{	return dataEmissione;
	}

	public String getCittaEmissione() 
	{	return cittaEmissione;
	}

	public ArrayList<String> getTag() 
	{	return new ArrayList<String>(tag);
	}
	
	public String toString()
	{	return "Tweet con codice "+codice+" emesso dall'utente con CF "+CFutente+" in data "+dataEmissione+
			" dalla citt� "+cittaEmissione+" con tag "+tag;
	}
	
	public boolean equals(Object o)
	{	if(o == this)
			return true;
		if(o == null)
			return false;
		if(!(o instanceof Utente))
			return false;
		Tweet t = (Tweet)o;
		return codice.equals(t.codice);		
	}
}
