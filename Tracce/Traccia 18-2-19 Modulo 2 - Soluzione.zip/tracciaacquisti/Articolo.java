package tracciaacquisti;

import java.util.*;

public class Articolo implements Comparable<Articolo>
{	private String codice;
	private ArrayList<Cliente> acquirenti;
	private int dataMessaInVendita;
	
	public Articolo(String codice, int dataMessaInVendita)
	{	this.codice = codice;
		this.acquirenti = new ArrayList<>();
		this.dataMessaInVendita = dataMessaInVendita;		
	}

	public Articolo(Articolo a)
	{	codice = a.getCodice();
		acquirenti = a.getAcquirenti();
		dataMessaInVendita = a.getDataMessaInVendita();
	}
	
	public String getCodice()
	{	return codice;		
	}
	
	public ArrayList<Cliente> getAcquirenti()
	{	return new ArrayList<Cliente>(acquirenti);		
	}
	
	public int getDataMessaInVendita()
	{	return dataMessaInVendita;
	}
	
	public void aggiungiAcquirente(Cliente acquirente)
	{	acquirenti.add(acquirente);		
	}
	
	public int hashCode()
	{	return codice.hashCode();		
	}
	
	public boolean equals(Object o)
	{	if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof Articolo))
			return false;
		Articolo a = (Articolo)o;
		return codice.equals(a.codice);
	}
	
	public String toString()
	{	return "Articolo con codice "+codice+", acquirenti: "+acquirenti+
				", messo in vendita in data "+dataMessaInVendita;		
	}
	
	public int compareTo(Articolo a)
	{	if(dataMessaInVendita < a.dataMessaInVendita)
			return -1;
		if(dataMessaInVendita > a.dataMessaInVendita)
			return 1;
		return 0;
	}
}
