package tracciaacquisti;

import java.util.*;

public class Sistema 
{	private ArrayList<Cliente> clienti;
	private ArrayList<Articolo> articoli;

	public Sistema(ArrayList<Cliente> clienti, ArrayList<Articolo> articoli)
	{	this.clienti = new ArrayList<Cliente>(clienti);
		this.articoli = new ArrayList<Articolo>(articoli);
	}
	
	public ArrayList<String> articoliCitta(String c)
	{	HashSet<Cliente> clientiInteresse = new HashSet<>();
		for(Cliente cliente : clienti)
			if(cliente.getCitta().equals(c))
				clientiInteresse.add(cliente);
		
		ArrayList<String> ret = new ArrayList<>();
		for(Articolo articolo : articoli)
		{	boolean acquistatoDaTutti = true;
			for(Cliente cliente : clientiInteresse)
				if(!articolo.getAcquirenti().contains(cliente))
				{	acquistatoDaTutti = false;
					break;
				}
			if(acquistatoDaTutti)
				ret.add(articolo.getCodice());
		}
		return ret;
	}

	public ArrayList<Cliente> acquirentiUnici(int d1, int d2)
	{	HashSet<Cliente> ret = new HashSet<>();
		for(Articolo articolo : articoli)
			if(articolo.getDataMessaInVendita() >= d1
					&& articolo.getDataMessaInVendita() <= d2
					&& articolo.getAcquirenti().size()==1)
				ret.add(articolo.getAcquirenti().get(0));
		return new ArrayList<Cliente>(ret);		
	}
	
	public ArrayList<Articolo> acquirentiComuni(Cliente a, Cliente b)
	{	ArrayList<Articolo> ret = new ArrayList<>();
		for(Articolo articolo : articoli)
			if(articolo.getAcquirenti().contains(a)
					&& articolo.getAcquirenti().contains(b))
				ret.add(new Articolo(articolo));
		Collections.sort(ret);
		Collections.reverse(ret);
		return ret;		
	}
	
	public HashMap<Cliente, Integer> statistiche()
	{	HashMap<Cliente, Integer> ret = new HashMap<>();
		for(Articolo articolo : articoli)
			for(Cliente cliente : articolo.getAcquirenti())
				if(!ret.containsKey(cliente))
					ret.put(cliente, 1);
				else
				{	int n = ret.get(cliente);
					n++;
					ret.put(cliente, n);
				}
		return ret;
	}
}
