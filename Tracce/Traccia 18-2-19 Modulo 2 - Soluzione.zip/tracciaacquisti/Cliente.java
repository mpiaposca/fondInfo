package tracciaacquisti;

public class Cliente 
{	private String nome;
	private String citta;
	
	public Cliente(String nome, String citta)
	{	this.nome=nome;
		this.citta=citta;
	}
	
	public String getNome()
	{	return nome;
	}
	
	public String getCitta()
	{	return citta;		
	}
	
	public String toString()
	{	return nome+" di "+citta;		
	}
	
	public int hashCode()
	{	return nome.hashCode();		
	}
	
	public boolean equals(Object o)
	{	if(o==null)
			return false;
		if(o==this)
			return true;
		if(!(o instanceof Cliente))
			return false;
		Cliente c = (Cliente)o;
		return nome.equals(c.nome);
	}
}
