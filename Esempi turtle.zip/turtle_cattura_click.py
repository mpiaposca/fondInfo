import turtle

def quadrati(x,y):
    print(x,y)
    turtle.up()
    turtle.setposition(x-10, y+10)
    turtle.down()
    turtle.color('blue')
    turtle.pensize(2)
    turtle.forward(20)
    turtle.right(90)
    turtle.forward(20)
    turtle.right(90)
    turtle.forward(20)
    turtle.right(90)
    turtle.forward(20)
    turtle.right(90)

def main():
    turtle.speed(0)
    turtle.hideturtle()
    turtle.onscreenclick(quadrati)

main()

