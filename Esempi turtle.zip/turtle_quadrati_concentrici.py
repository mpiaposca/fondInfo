import turtle
  
def disegna_quadrati_concentrici(n,lato_iniziale,incremento):
    x_iniziale, y_iniziale = turtle.position()
    lato = lato_iniziale
    for i in range(n):
        #sposta a NW
        turtle.up()
        turtle.setposition(x_iniziale - lato//2, y_iniziale + lato//2) 
        #disegna quadrato
        turtle.down()
        turtle.pensize(4)
        turtle.color('blue')
        turtle.forward(lato)
        turtle.right(90)
        turtle.forward(lato)
        turtle.right(90)
        turtle.forward(lato)
        turtle.right(90)
        turtle.forward(lato)
        turtle.right(90)
        #sposta al centro
        turtle.up()
        turtle.setposition(x_iniziale, y_iniziale) 
        #calcola nuovo lato
        lato += incremento

def main():
    disegna_quadrati_concentrici(10,50,20)

main()
