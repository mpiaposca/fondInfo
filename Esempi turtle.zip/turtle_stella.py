import turtle 

turtle.color('red')
turtle.pensize(2)
for i in range(36):
    turtle.forward(100)
    turtle.left(170)
    
