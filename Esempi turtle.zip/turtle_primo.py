import turtle

print(turtle.position())

turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.color('blue')
turtle.pensize(4)
turtle.right(90)
turtle.forward(100)
turtle.up()
turtle.forward(100)
turtle.down()
turtle.forward(100)
turtle.left(90)
turtle.forward(50)
turtle.up()
turtle.setposition(0, 0)
