import turtle

def disegna_barra(altezza,larghezza):
    # Assume turtle orientata a destra
    # Lascia turtle orientata a destra
    turtle.left(90)
    turtle.forward(altezza)
    turtle.right(90)
    turtle.forward(larghezza)
    turtle.right(90)
    turtle.forward(altezza)
    turtle.left(90)

def disegna_grafico_barre(l,distanza_barre,lunghezza_asse):
    larghezza_barre = (lunghezza_asse-len(l)*distanza_barre)//len(l)
    turtle.color('blue')
    turtle.pensize(4)
    turtle.forward(lunghezza_asse//2)
    turtle.backward(lunghezza_asse)
    for v in l:
        disegna_barra(altezza=v,larghezza=larghezza_barre)
        turtle.forward(distanza_barre)
    
def main():
    l=[10,20,300,80,160,80,40,20,10]
    disegna_grafico_barre(l, distanza_barre = 30, lunghezza_asse = 800)

main()
