def scrivi_lista(lista,nome_file):
    f = open(nome_file,'w')
    f.write(str(lista[0]))
    for n in lista[1:]:
        f.write(','+str(n))
    f.write('\n')
    f.close()

def leggi_lista_interi(nome_file):
    ret = []
    f = open(nome_file, 'r')
    linea = f.readline()
    valori = linea.split(',')
    for x in valori:
        ret.append(int(x))
    f.close()
    return ret

def scrivi_matrice(matrice,nome_file):
    f = open(nome_file,'w')
    for riga in matrice:
        f.write(str(riga[0]))
        for n in riga[1:]:
            f.write(','+str(n))
        f.write('\n')
    f.close()
    
def leggi_matrice_interi(nome_file):
    ret = []
    f = open(nome_file, 'r')
    for linea in f:
        riga = []
        valori = linea.split(',')
        for x in valori:
            riga.append(int(x))
        ret.append(riga)
    f.close()
    return ret

