package listeconcatenate;

import java.util.*;

class NodoInt
{
	private int info;
	private NodoInt successivo;

	public NodoInt(int info, NodoInt successivo)
	{
		this.info = info;
		this.successivo = successivo;
	}

	public int getInfo()
	{
		return info;
	}

	public NodoInt getSuccessivo()
	{
		return successivo;
	}

	public void setInfo(int info)
	{
		this.info = info;
	}

	public void setSuccessivo(NodoInt successivo)
	{
		this.successivo = successivo;
	}

	public boolean haInfo(int info)
	{
		return this.info == info;
	}

	public String toString()
	{
		return ""+info;
	}
}

public class ListaConcatenataInt
{
	private int lunghezza;
	private NodoInt testa;
	private NodoInt coda;

	private void inizializza()
	{
		lunghezza = 0;
		testa = null;
		coda = null;
	}

	public ListaConcatenataInt()
	{
		inizializza();
	}

	public ListaConcatenataInt(ListaConcatenataInt l)
	{
		inizializza();
		for(NodoInt n = l.testa; n != null; n = n.getSuccessivo())
			aggiungiInCoda(n.getInfo());
	}

	public ListaConcatenataInt(int[] a)
	{
		inizializza();
		for(int info : a)
			aggiungiInCoda(info);
	}

	public int getLunghezza()
	{
		return lunghezza;
	}

	public boolean eVuota()
	{
		return lunghezza == 0;
	}

	public void svuota()
	{
		inizializza();
	}

	public void aggiungiInCoda(int info)
	{
		NodoInt nuovoNodo = new NodoInt(info,null);
		if (eVuota())
		{
			testa = nuovoNodo;
			coda = nuovoNodo;
		}
		else
		{
			coda.setSuccessivo(nuovoNodo);
			coda = nuovoNodo;
		}
		lunghezza++;
	}

	public void aggiungiInTesta(int info)
	{
		NodoInt nuovoNodo = new NodoInt(info,testa);
		testa = nuovoNodo;
		if (coda == null)
			coda = nuovoNodo;
		lunghezza++;
	}

	public String toString()
	{
		String s="[";
		for(NodoInt n = testa; n != null; n = n.getSuccessivo())
		{
			s += n;
			if(n.getSuccessivo() != null)
				s += ", ";
		}
		s += "]";
		return s;
	}

}







